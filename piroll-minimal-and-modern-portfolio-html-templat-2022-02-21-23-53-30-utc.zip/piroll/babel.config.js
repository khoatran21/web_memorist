module.exports = {
    presets: [
        '@babel/env',
    ],
};
